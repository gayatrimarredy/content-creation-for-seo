# gtsdb
gtsdb is a high performance distributed time series database writen by golang
